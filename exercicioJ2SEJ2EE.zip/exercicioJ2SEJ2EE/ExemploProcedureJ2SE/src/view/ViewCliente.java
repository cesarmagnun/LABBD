package view;

import java.awt.EventQueue;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

import controller.ControllerCliente;

import javax.swing.JButton;

public class ViewCliente {

	private JFrame frame;
	private JTextField txtNome;
	private JTextField txtTelefone;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ViewCliente window = new ViewCliente();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public ViewCliente() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNome = new JLabel("Nome");
		lblNome.setBounds(67, 73, 46, 14);
		frame.getContentPane().add(lblNome);
		
		JLabel lblTelefone = new JLabel("Telefone");
		lblTelefone.setBounds(67, 122, 46, 14);
		frame.getContentPane().add(lblTelefone);
		
		txtNome = new JTextField();
		txtNome.setBounds(135, 70, 86, 20);
		frame.getContentPane().add(txtNome);
		txtNome.setColumns(10);
		
		txtTelefone = new JTextField();
		txtTelefone.setBounds(135, 119, 86, 20);
		frame.getContentPane().add(txtTelefone);
		txtTelefone.setColumns(10);
		
		JButton btnEnviar = new JButton("Enviar");
		btnEnviar.setBounds(162, 194, 89, 23);
		frame.getContentPane().add(btnEnviar);
		
		ActionListener chamadaCliente = new ControllerCliente(txtNome, txtTelefone);
		btnEnviar.addActionListener(chamadaCliente);
		
	}
}
