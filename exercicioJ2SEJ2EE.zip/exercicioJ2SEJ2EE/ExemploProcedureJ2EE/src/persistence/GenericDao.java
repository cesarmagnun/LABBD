package persistence;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.sql.ConnectionEvent;

public class GenericDao {
	
	private Connection con;
	
	private String user = "cesar";
	private String password = "123456";
	private String url = "jdbc:jtds:sqlserver://localhost:1433;instance=SQLEXPRESS;DataBaseName=LBD;namedPipe=true";
	
	
	public Connection getConnection() {
		
		try {
			Class.forName("net.sourceforge.jtds.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			con = DriverManager.getConnection(url, user, password);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("Conex�o com sucesso!!!");
		return con;
	}
	
	
	
	
	
	

}
